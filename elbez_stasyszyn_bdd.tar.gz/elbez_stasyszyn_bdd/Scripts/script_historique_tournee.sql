\i init.sql
SELECT lieux_spectacles();
